Arquivo zip gerado em: 28/05/2025 14:09:30 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho Prático 1